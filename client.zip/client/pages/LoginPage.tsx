import { useState } from "react";

interface LoginPageProps {
  onLogin: (email: string, isAdmin: boolean) => void;
}

const VALID_USERS = [
  { email: "aavneet.johar@herovired.com", password: "Hx0007", isAdmin: true },
  { email: "trainings@herovired.com", password: "Hx0000", isAdmin: true },
];

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const user = VALID_USERS.find((u) => u.email === email && u.password === password);

    if (user) {
      onLogin(email, user.isAdmin);
    } else {
      setError("Invalid credentials");
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-cover bg-center relative"
      style={{
        backgroundImage: "url('https://cdn.builder.io/api/v1/image/assets%2F88805948443b4c8f889eb67f299fc007%2F147ce9f561de4ad18f3a12346131fc96?format=webp&width=800&height=1200')",
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-black/70"></div>

      {/* Login card */}
      <div className="relative z-10 w-full max-w-md">
        <div className="glass-card p-8 md:p-12 space-y-6">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">
              Vired Pulse
            </h1>
            <p className="text-lg text-white/80">Your AI-like Call Assistant</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input
                type="email"
                placeholder="Enter Hero Vired Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/30 text-white placeholder:text-white/60 focus:outline-none focus:border-primary focus:bg-white/20 transition-all"
              />
            </div>

            <div>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/30 text-white placeholder:text-white/60 focus:outline-none focus:border-primary focus:bg-white/20 transition-all"
              />
            </div>

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-500/20 py-2 px-3 rounded-lg">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="vired-btn w-full text-lg py-3 rounded-xl"
            >
              Login / Sign Up
            </button>
          </form>

          <p className="text-center text-white/60 text-sm">
            Demo Credentials: tranings@herovired.com / Hx0000
          </p>
        </div>
      </div>
    </div>
  );
}
